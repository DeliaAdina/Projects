	function verificaNumar()
	{ 
		var n = prompt("Introduceti numarul");
		if ((n % 2) == 0)
			alert("numarul este par!");
		else
			alert("numarul este impar!");
	}
	
	function calculeazaTVA()
	{ 
		var n = prompt("Introduceti suma");
		var pretCuTVA = n * 1.19; 
		alert("Pret cu TVA este: "+ pretCuTVA);		
	}