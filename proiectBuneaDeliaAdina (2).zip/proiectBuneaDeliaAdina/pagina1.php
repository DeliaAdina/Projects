<html>
	<head>
    <title>DespreNoi</title>  
  	<style>
  	body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #B0C4DE;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
p{
	text-align:center; 
	color:black;
	font-size: 25px;
	font-family: 'Abril Fatface', serif
}
	* {
  box-sizing: border-box;
}

.img-container {
  float: left;
  width: 33.33%;
  padding: 5px;
}

.clearfix::after {
  content: "";
  clear: both;
  display: table;
}
		</style>
  </head>   
  <body>
  <div class="topnav">
    <a href="index.php">Pagina Principala</a>
    <a class="active" href="pagina1.php">Despre Noi</a>
    <a href="PrimulNivel\pagina2.php">Produsele noastre</a>
    <a href="primulNivel\alDoileaNivel\pagina3.php">Plaseaza comanda</a>
    <a href="primulNivel\alDoileaNivel\alTreileaNivel\pagina4.php">Parerile clientilor</a>
  </div>
  <br><br><br><br><br>
  <h1 style="text-align:center;" style="font-size:50px;">Cine suntem noi?</h1>
  <br>
  <br>
  <p>Aceasta afacere a inceput din pasiunea a doi tineri pentru <i>narghilea</i>. <br> Noi va oferim ocazia sa comandati tot ce aveti nevoie pentru a va bucura de o narghilea de calitate, fara a fi nevoiti sa parasiti propriul confort de acasa. <br> Momentan, livram in urmatoarele localitati: Cluj-Napoca, Floresti, Apahida. <br><br></p>
    <p style="color:red;"><i>Atentie: Aceste produse se adreseaza doar persoanelor cu varsta peste 18 ani!</i></p>
  <div class="clearfix">
    <div class="img-container">
      <img src="primulNivel/imagini/accesorii.png" alt="accesorii" style="width:100%">
    </div>
    <div class="img-container">
      <img src="primulNivel/imagini/aroma.png" alt="aroma" style="width:100%">
    </div>
    <div class="img-container">
      <img src="primulNivel/imagini/tutun.png" alt="tutun" style="width:100%">
    </div>
  </div>
  <br><br>
</body>
</body>
</html>