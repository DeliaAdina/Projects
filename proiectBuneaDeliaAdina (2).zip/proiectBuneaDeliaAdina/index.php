<html>
  <head>
    <title>ShishaOn</title>
	<meta name="description" content="Comenzi online de narghilea si accesorii, width=device-width, initial-scale=1" />
	<meta name="keywords" content="narghilea, accesorii, arome, carbuni" />
	<meta name="author" content="Delia Adina Bunea Co" />
	<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background: url('primulNivel/imagini/Homepage.png');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
p{
	text-align:center; 
	color:#F5F5DC;
	font-size: 40px;
}
h1 {
  font-size: 80px;
}
address {
	text-align: right;
	text-indent: 80px;
	padding-right: 50px;
  color:#F5F5DC;
	}
</style>
  </head>   
  <body>
  <div class="topnav">
    <a class="active" href="index.php">Pagina principala</a>
    <a href="pagina1.php">Despre noi</a>
    <a href="primulNivel\pagina2.php">Produsele noastre</a>
    <a href="primulNivel\alDoileaNivel\pagina3.php">Plaseaza comanda</a>
    <a href="primulNivel\alDoileaNivel\alTreileaNivel\pagina4.php">Parerile clientilor</a>
  </div>
  <br><br><br><br><br><br><br><br>
  <h1 style="text-align:center; color:#FFEBCD;">ShishaOn</h1>
  <p>Primul site din Cluj de unde poti comanda online narghilea direct <span>
      <b>acasa la tine.</span>
    </b></p>
  <br><br><br><br><br><br><br><br><br><br><br>
  <address> ShishaOn <br> Creat de Fam. Bunea <br> Viziteaza-ne la: <br> www.ShishaOn.com <br> Romania <br>
    <a href="mailto:delia_adina95@yahoo.com?subject=Intrebare+magazin"> Contacteaza-ne pe mail</a>
  </address>
</body>
</html>