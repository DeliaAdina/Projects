<html>
  <head>
    <title>ProduseleNoastre</title>
    <style>
    	body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #B0C4DE;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

table, th, td {
  border:1px solid black;
}

.styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    margin-left: 30px;
}
.styled-table thead tr {
    background-color: #5F9EA0;
    color: #ffffff;
    text-align: left;
}
.styled-table th,
.styled-table td {
    padding: 12px 15px;
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
}

.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
}
.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
}

img {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 300px;
  height: 300px;
  border-radius: 25px;
}
  li {
  	font-size: 20px;
    color: black;
    text-shadow: 1px 1px 2px #000000;
  }
h1 {
	font-size: 20px
}
.container {
  display: flex;
  border-radius: 25px;
  flex-wrap: wrap;
}    
.container .card {
  float: left;
  width: 33.33%;
  padding: 5px;
  border-radius: 25px;
  box-sizing: border-box;
}
.flip-card {
  background-color: transparent;
  width: 300px;
  height: 300px;
  perspective: 1000px;
  margin:20px;
  margin-bottom: 60px;
  border-radius: 25px;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  border-radius: 25px;
}

.flip-card:hover .flip-card-inner {
  transform: rotateY(180deg);
}

.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  border-radius: 25px;
}

.flip-card-front {
  background-color: #bbb;
  color: black;
  border-radius: 25px;
}

.flip-card-back {
  background-color: #2980b9;
  color: white;
  transform: rotateY(180deg);
  border-radius: 25px;
} 

.table {
  display: table;  
  margin: 0 auto;
}

ul#horizontal-list {
  min-width: 696px;
  list-style: none;
  padding-top: 20px;
  }
  ul#horizontal-list li {
    display: inline;
    font-size: 25px;
  }
  li {
   display:inline-block;
   padding: 80px;
}
</style>
<script src="https://kit.fontawesome.com/3427809a13.js" crossorigin="anonymous"></script>
  </head>   
  <body>
  <div class="topnav">
   <a href="../index.php">Pagina Principala</a>
   <a href="../pagina1.php">Despre noi</a>
   <a class="active" href="pagina2.php">Produsele Noastre</a>
   <a href="alDoileaNivel\pagina3.php">Plaseaza comanda</a>
	 <a href="alDoileaNivel\alTreileaNivel\pagina4.php">Parerile clientilor</a>
</div>
<br><br>
  <div class="table">
  <ul type="disc" id="horizontal-list">
		<li><a href="#Nrg"><i class="fas fa-cart-arrow-down"></i> Narghilea</a></li>
		<li><a href="#Acc"><i class="fas fa-cart-arrow-down"></i> Accesorii narghilea</a></li>
		<li><a href="#Cons"><i class="fas fa-cart-arrow-down"></i> Consumabile narghilea</a></li>
    <li><a href="#Pret"><i class="fas fa-cart-arrow-down"></i> Lista preturi</a></li>
  </ul>
  </div>
	<br>
	<h2 id="Nrg"><i class="fas fa-angle-double-right"></i> Narghilea</h2>
	<br>
	<br>
	<div class="container">
	<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\MiniTower.png" alt="Mini Tower" style="width:300px;height:300px;">
      <p>COCO BOSS- MINI TOWER 360°</p>
    </div>
    <div class="flip-card-back">
      <h1>COCO BOSS- MINI TOWER 360°</h1> 
      <p>450,00 Lei<br><br>Toate piesele metalice sunt fabricate din aluminiu folosind prelucrări CNC, sablare și anodizare.<br>Furtunul este fabricat din silicon mat cu mâner din aluminiu.</p> 
      <p>Greutate Totala Neta: 3 kg<br>Inaltime:	42 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\SmokeLady.png" alt="Smoke Lady" style="width:300px;height:300px;">
       <p>Coco Boss Smoke Ladys</p>
    </div>
    <div class="flip-card-back">
      <h1>Narghilea Coco Boss Smoke Ladys</h1> 
      <p>749,00 Lei<br><br>Toate piesele metalice sunt fabricate din aluminiu folosind prelucrări CNC, sablare și anodizare.</p> 
      <p>Greutate Totala Neta: 3 kg<br>Inaltime:	35 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\4Stars.png" alt="4Stars" style="width:300px;height:300px;">
      <p>4Stars 410</p>
    </div>
    <div class="flip-card-back">
      <h1>4Stars 410</h1> 
      <p>295,00 Lei<br><br>4Stars 410 este o narghilea din alama (amestec de cupru si zinc), dimensiune medie de 60 cm, si are 2 conexiuni (permite montarea a pana la 2 furtune)</p> 
      <p>Greutate Totala Neta: 4 kg<br>Inaltime:	60 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\AluSierra.png" alt="Alu Sierra" style="width:300px;height:300px;">
      <p>ALU SIERRA S</p>
    </div>
    <div class="flip-card-back">
      <h1>ALU SIERRA S</h1> 
      <p>425,00 Lei<br><br>Alu Sierra S este o narghilea din aluminiu, dimensiune medie de 65 cm, si are 2 conexiuni (permite montarea a pana la 2 furtune)</p> 
      <p>Greutate Totala Neta: 4.4 kg<br>Inaltime:	65 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\Starbuzz.png" alt="Starbuzz" style="width:300px;height:300px;">
      <p>STARBUZZ CARBINE 2.0</p>
    </div>
    <div class="flip-card-back">
      <h1>STARBUZZ CARBINE 2.0</h1> 
      <p>1 500,00 Lei<br><br>Perfect pentru acasă sau pentru călătorii. Ușor de asamblat, demontat, curățat și depozitat.</p> 
      <p>Greutate Totala Neta: 7 kg<br>Inaltime:	65 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\AmirsKarat.png" alt="Amirs Karat" style="width:300px;height:300px;">
      <p>AMIRS KARAT X</p>
    </div>
    <div class="flip-card-back">
      <h1>AMIRS KARAT X</h1> 
      <p>1 490,00 Lei<br><br>O formă atemporală și elegantă.<br>Coloana de fum impresionează printr-un ton elegant de aur și pietre decorative strălucitoare care sunt garantate pentru a atrage atenția tuturor.</p> 
      <p>Inaltime:	70 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\Foggy.png" alt="Foggy" style="width:300px;height:300px;">
      <p>FOGGY</p>
    </div>
    <div class="flip-card-back">
      <h1>FOGGY</h1> 
      <p>760,00 Lei<br><br>COCO BOSS FOGGY este o narghilea premium din aluminiu anodizat, dimensiune de birou / masa (52 cm impreuna cu creuzet), cu bază acrilică, aerisire invizibilă cu 4 colţuri, suportă până la 2 furtunuri conectate simultan.</p> 
      <p>Greutate Totala Neta:	2,5 kg<br>Inaltime:	52 cm</p>
    </div>
  </div>
</div>
</div>
	<br><br><br><br>
	<h2 id="Acc"><i class="fas fa-angle-double-right"></i> Accesorii narghilea</h2>
	<br><br>
  <div class="container">
	<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\HotBurner.png" alt="Hot Burner" style="width:300px;height:300px;">
      <p>APRINZATOR ELECTRIC HOT BURNER 500W</p>
    </div>
    <div class="flip-card-back">
      <h1>APRINZATOR ELECTRIC HOT BURNER 500W</h1> 
      <p>75,00 Lei<br><br>Aprinzator Carbuni de narghilea Electric COCO BOSS HOT BURNER BS-A001 500W este utilizată în special pentru aprinderea carbunului natural in toate formele. </p> 
      <p>Greutate Totala Neta: 0,5 kg</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\SuportCarbuniMediu.png" alt="Suport Carbuni Mediu" style="width:300px;height:300px;">
      <p>SUPORT CARBUNI MEDIU</p>
    </div>
    <div class="flip-card-back">
      <h1>SUPORT CARBUNI MEDIU</h1> 
      <p>80,00 Lei<br><br>Suport (cos) carbuni AMY Deluxe mediu</p> 
      <p>Înălțime: 46 cm<br>Diametru: 14 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\SitaCarbuni.png" alt="Suport Carbuni Mediu" style="width:300px;height:300px;">
      <p>GRATAR SITA CARBUNI COCO BOSS</p>
    </div>
    <div class="flip-card-back">
      <h1>GRATAR SITA CARBUNI COCO BOSS</h1> 
      <p>15,00 Lei<br><br>Gratarul pentru Sita metalica COCO BOSS se potrivește cu sitele de carbuni de la COCO BOSS si AMY Deluxe.</p> 
      <p>Diametru: 9 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\IceBazooka.png" alt="Ice Bazooka" style="width:300px;height:300px;">
      <p>ICE BAZOOKA FROST</p>
    </div>
    <div class="flip-card-back">
      <h1>ICE BAZOOKA FROST</h1> 
      <p>31,50 Lei<br><br>Manerul se baga in congelator pentru a fi inghetat inainte de folosire.<br>El va oferi o senzatie racoritoare utilizatorului de narghilea.</p> 
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\PerieVas.png" alt="Perie Vas" style="width:300px;height:300px;">
      <p>PERIE VAS COCO BOSS</p>
    </div>
    <div class="flip-card-back">
      <h1>PERIE VAS COCO BOSS</h1> 
      <p>20,00 Lei<br><br>Peria este un accesoriu necesar pentru cei care folosesc narghileaua. Cu această perie de curățare, puteți curăța cu ușurință și convenabil vasul (sticla) de narghilea.</p> 
      <p>Lungime Peria: 30 cm<br>Lungime cu maner: 50 cm<br>Diamitru maxim: 12 cm<br>Diamitru Minim: 3 cm</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\ClesteCarbuni.png" alt="Cleste Carbuni" style="width:300px;height:300px;">
      <p>CLESTE CARBUNI MIC COCO BOSS</p>
    </div>
    <div class="flip-card-back">
      <h1>CLESTE CARBUNI MIC COCO BOSS</h1> 
      <p>7,00 Lei<br><br>Cleste COCO BOSS pentru carbuni marima mica.</p> 
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\FiltruSticla.png" alt="Filtru Sticla" style="width:300px;height:300px;">
      <p>FILTRU STICLA SKULL - MELASSA CATCHER</p>
    </div>
    <div class="flip-card-back">
      <h1>FILTRU STICLA SKULL - MELASSA CATCHER</h1> 
      <p>85,00 Lei<br><br>Filtru (Melassa Catcher) din Sticla AMY Deluxe cu forma de Craniu</p>
      <p>Inaltime:	19 cm</p> 
    </div>
  </div>
</div>
</div>
	<br><br><br><br>
	<h2 id="Cons"><i class="fas fa-angle-double-right"></i> Consumabile Narghilea</h2>
		<br><br>
	<div class="container">
	<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\Carbuni.png" alt="Carbuni" style="width:300px;height:300px;">
      <p>CARBUNI AMY DELUXE</p>
    </div>
    <div class="flip-card-back">
      <h1>CARBUNI AMY DELUXE 26MM 1KG</h1> 
      <p>28,00 Lei<br><br>Cărbunele natural AMY este produs în Indonezia și este obținut din coji de nucă de cocos, adică este format din materii prime 100% naturale, regenerabile.</p> 
      <p>Greutate Totala Neta: 1 kg</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\TabooBlueBay.png" alt="Taboo Blue Bay" style="width:300px;height:300px;">
      <p>TUTUN NARGHILEA TABOO BLUE BAY</p>
    </div>
    <div class="flip-card-back">
      <h1>TUTUN NARGHILEA TABOO BLUE BAY - AFINE CU MENTA</h1> 
      <p>60,00 Lei<br><br>Tutun de narghilea TABOO BLUE BAY cu gust de Afine cu Menta </p> 
      <p>Greutate Totala Neta: 50 g</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\CherryLips.png" alt="Cherry Lips" style="width:300px;height:300px;">
      <p>AROMA HOOKING 50G CHERRY LIPS</p>
    </div>
    <div class="flip-card-back">
      <h1>AROMA HOOKING 50G CHERRY LIPS</h1> 
      <p>24,00 Lei<br><br>Aroma Narghilea HOOKING CHERRY LIPS 50g cu Gust de Cirese cu Gheata.</p> 
      <p>Greutate Totala Neta: 50 g</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\Mustiucuri.png" alt="Mustiucuri" style="width:300px;height:300px;">
      <p>SET MUSTIUCURI COCO BOSS</p>
    </div>
    <div class="flip-card-back">
      <h1>SET MUSTIUCURI COCO BOSS MARI</h1> 
      <p>20,00 Lei<br><br>Se potrivesc la furtunele de silicon cu maner metalic (AMY, DUMAN, MS, COCO BOSS, etc).</p> 
      <p>Bucati in set = 100</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\Colorant.png" alt="Colorant" style="width:300px;height:300px;">
      <p>SPARKLINO TURQUOISE</p>
    </div>
    <div class="flip-card-back">
      <h1>SPARKLINO TURQUOISE</h1> 
      <p>40,00 Lei<br><br>Cu doar o linguriță poți colora apa din vas așa cum vrei tu. </p> 
      <p>Greutate Totala Neta: 50 g</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\Melasa.png" alt="Melasa" style="width:300px;height:300px;">
      <p>MELASA AL WAHA COCO LEMON</p>
    </div>
    <div class="flip-card-back">
      <h1>MELASA AL WAHA COCO LEMON</h1> 
      <p>45,00 Lei<br><br>Melasa aromata AL WAHA COCO LEMON cu gust de Cocos si Lamie 250g, se amestica cu aromele pe baza de tutun, plante, ceai, pietre sau cristale ca sa da gust mai concentrat si fum mai intens.</p> 
      <p>Greutate Totala Neta: 	250 g</p>
    </div>
  </div>
</div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="imagini\FolieAluminiu.png" alt="Folie Aluminiu" style="width:300px;height:300px;">
      <p>FOLIE ALUMINIU</p>
    </div>
    <div class="flip-card-back">
      <h1>FOLIE ALUMINIU</h1> 
      <p>20,00 Lei<br><br>Folii aluminiu neperforate folosite pentru acoperirea tutunului sau aromei din creuzet.</p> 
      <p>O rola contine 25m de dimensiunea 12cm.</p>
    </div>
  </div>
</div>
</div>
<h2 id="Pret"><i class="fas fa-angle-double-right"></i> Lista preturi</h2>
<?php include "alDoileaNivel/connect_database.php" ?>
<table class="styled-table">
    <thead>
    <tr>
      <td>Categorie</td>
      <td>Tip produs</td>
      <td>Marca</td>
      <td>Pret (lei)</td>
    </tr>
  </thead>
    <?php 
    $sql = "SELECT categorii.`categorie`, produse.`Tip produs`, produse.`Marca`, produse.`Pret` FROM `produse`, `categorii` WHERE produse.id_categorie = categorii.id order by Categorie, Pret asc";
    $result = $conn->query($sql);
      if ($result->num_rows > 0)
      {
        while ($row = $result->fetch_assoc()) 
        {
        echo "<tr><td>" .$row["categorie"]. "</td><td>". $row["Tip produs"] ."</td><td>" . $row["Marca"]. "</td><td>" . $row["Pret"] . "</td></tr>";
        }
      }
      else
      {
        echo "Nu sunt rezultate!";
      }

    $conn->close();
    ?>
  </body>
</html>