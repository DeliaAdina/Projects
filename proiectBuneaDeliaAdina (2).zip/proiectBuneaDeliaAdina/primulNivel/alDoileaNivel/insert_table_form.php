<html>
    <head>
    <title>DateleComenzii</title>
    <style>
    	body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background: url('../imagini/OrderReceived.png');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
    </head>
    <body>
    	<div class="topnav">
   <a href="../../index.php">Pagina Principala</a>
   <a href="../../pagina1.php">Despre noi</a>
   <a href="../pagina2.php">Produsele Noastre</a>
   <a class="active" href="pagina3.php">Plaseaza comanda</a>
   <a href="alTreileaNivel\pagina4.php">Parerile clientilor</a>
</div>
        <br><br>
			<strong>Se salveaza datele!</strong>
      <br><br>
			<?php 
			include 'connect_database.php';
			  echo "Salutare ... datele comenzii pe care dorim sa le salvam sunt: <br><br>Nume: ".$_POST['nume']."<br>Prenume:".$_POST['prenume']."<br>Telefon: ".$_POST['telefon']."<br>Adresa: ".$_POST['adresa']." <br>Produse:".$_POST['mesaj'];
            $sql = "INSERT INTO comenzi (Nume, Prenume, Telefon, Adresa, Produse) VALUES ('".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["telefon"]."','".$_POST["adresa"]."','".$_POST["mesaj"]."')";
			if ($conn->query($sql) === TRUE) {
				echo "<br><br>New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
			?>
        <br>
        </div>
    </body>
</html>