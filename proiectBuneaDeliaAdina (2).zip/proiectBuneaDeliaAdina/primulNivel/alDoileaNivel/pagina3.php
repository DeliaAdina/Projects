<html>
  <head>
    <title>PlaseazaComanda</title>
    <meta name="PlaseazaComanda" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../PrimulNivel/Referinte/stilulmeu.css">	
     <script type="text/javascript">
    function checkform()
            {
                if (verificaNume() && verificaPrenume() && verificaTelefon() 
                    && verificaAdresa() && verificaMesaj()
                )
                return true;
            }
            
        function verificaNume()
       {
        var stringNume = document.getElementById("numeId").value;
        var alfabet = "^[a-zA-Z]+$";
        var numecorect = true;
        if (stringNume.match(alfabet))
        {
            document.getElementById("numeId").style.background = "white";
            return true;
        }
        else
        {
            document.getElementById("numeId").style.background = "red";            
            numecorect = false;
        }
        if (!numecorect)
        {
          alert("Numele introdus este incorect!"); 
          return false;                       
        }
       }

       function verificaPrenume()
       {
        var stringNume = document.getElementById("prenumeId").value;
        var alfabet = "^[a-zA-Z]+$";
        var prenumecorect = true;
        if (stringNume.match(alfabet))
        {
            document.getElementById("prenumeId").style.background = "white";
            document.getElementById("prenumeId").innerHTML = "";
            return true;
        }
        else
        {
            document.getElementById("prenumeId").style.background = "red";            
            prenumecorect = false;
        }
        if (!prenumecorect)
        {
          alert("Prenumele introdus este incorect!"); 
          return false;                       
        }
       }

   function verificaTelefon() {
    var stringTelefon = document.getElementById("telefonId").value;
    var format = /^\d{10}$/;
    var telefoncorect = true;
    console.log('stringTelefon', stringTelefon)
        if (stringTelefon.match(format)) 
        {
            document.getElementById("telefonId").style.background = "green";
            return true;
        } else {
            alert("Numarul de telefon introdus are format incorect!");
            document.getElementById("telefonId").style.background = "red";
            return false;
        }
    }

    function verificaMesaj() {
    var Comanda = document.getElementById("mesajId").value;
    if (Comanda=="")
        {alert("Va rugam completati campul Comanda!");
        document.getElementById("mesajId").style.background = "red";
        return false;
        } else {
        document.getElementById("mesajId").style.background = "green";
            return true;
        }
    }

    function verificaAdresa() {
    var Adresa = document.getElementById("adresaId").value;
    if ((Adresa == null)||(Adresa==""))
        {alert("Va rugam completati campul Adresa!");
        document.getElementById("adresaId").style.background = "red";
        return false;
        } else {
        document.getElementById("adresaId").style.background = "green";
            return true;
        }
    }

     function SetProduct() {
    var mesajId = document.getElementById("mesajId");
    mesajId.value += document.getElementById("ddlNames").value + "\r " + "";
}
     </script>
  </head>   
  <body>
  <ul>
  <li><a href="../../index.php">Pagina Principala</a></li>
	<li><a href="../../pagina1.php">Despre noi</a></li>
	<li><a href="../pagina2.php">Produsele noastre</a></li>
	<li><a class="active" href="pagina3.php">Plaseaza Comanda</a></li>
	<li><a href="alTreileaNivel\pagina4.php">Parerile clientilor</a></li>
  </ul>
  <br><br>
  <strong><h1>Adauga o comanda</h1></strong>
	<br>
	<form method="post" action= "insert_table_form.php">
    <br><br>
    <fieldset>
		<legend><b>Detalii client</b></legend>
     <label for="numeId">Introduceti numele:
     <div class="tooltip">
        <input type="text" name="nume" id="numeId"/></label><br>
        <span class="tooltiptext"><small>Numele trebuie sa contina numai litere
        </small></span>
      </div>
     <br><br>
     <label for="prenumeId">Introduceti prenumele:
    <div class="tooltip">
     <input type="text" name="prenume" id="prenumeId"/></label>
     <span class="tooltiptext"><small><br>Prenumele trebuie sa contina numai litere
        </small></span>
        </div>
     <br><br>
     <label for="telefonId">Introduceti numarul de telefon:
     <input placeholder="0XXXXXXXXX" type="tel" name="telefon" id="telefonId" pattern="/^\d{10}$/"/></label>
     <br><small>Format:0123456789</small>
     <br><br>
     </fieldset>
     <br><br>
    <fieldset>
		<legend><b>Adresa de livrare</b></legend>
      <br>
      <label for="Adresa">Introduceti adresa:
     <input id="adresaId" type="text" name="adresa"/><br></label>
     <small>Format: nume strada, numar bloc/casa, etaj, numar apartament, localitate</small>
     <br>
     <span class="tooltiptext"><small><br>Taxa de livrare este 20 lei!
        </small></span>
      <br>
    </fieldset>
      <br><br>
      <fieldset>
      <legend><b>Detalii comanda</b></legend>
      <br><br>
Va rugam selectati produsele dorite din lista de mai jos:<br>
<select multiple="" name="ddlNames" id="ddlNames">
<option value="SUPORT CARBUNI MEDIU AMY Deluxe">SUPORT CARBUNI MEDIU AMY Deluxe</option>
<option value="APRINZATOR ELECTRIC HOT BURNER 500W AMY Deluxe">APRINZATOR ELECTRIC HOT BURNER 500W AMY Deluxe</option>
<option value="GRATAR SITA CARBUNI COCO BOSS">GRATAR SITA CARBUNI COCO BOSS</option>
<option value="RACORITOARE ICE BAZOOKA FROST AMY Deluxe">RACORITOARE ICE BAZOOKA FROST AMY Deluxe</option>
<option value="PERIE VAS COCO BOSS">PERIE VAS COCO BOSS</option>
<option value="CLESTE CARBUNI MIC COCO BOSS">CLESTE CARBUNI MIC COCO BOSS</option>
<option value="FILTRU STICLA SKULL - MELASSA CATCHER AMY Deluxe">FILTRU STICLA SKULL - MELASSA CATCHER AMY Deluxe</option>
<option value="CARBUNI AMY Deluxe">CARBUNI AMY Deluxe</option>
<option value="TUTUN NARGHILEA TABOO BLUE BAY AMY Deluxe">TUTUN NARGHILEA TABOO BLUE BAY AMY Deluxe</option>
<option value="AROMA NARGHILEA HOOKING CHERRY LIPS AMY Deluxe">AROMA NARGHILEA HOOKING CHERRY LIPS AMY Deluxe</option>
<option value="SET MUSTIUCURI COCO BOSS">SET MUSTIUCURI COCO BOSS</option>
<option value="COLORANT APA PARKLINO TURQUOISE AMY Deluxe">COLORANT APA PARKLINO TURQUOISE AMY Deluxe</option>
<option value="MELASA AL WAHA COCO LEMON AMY Deluxe">MELASA AL WAHA COCO LEMON AMY Deluxe</option>
<option value="FOLIE ALUMINIU COCO BOSS">FOLIE ALUMINIU COCO BOSS</option>
<option value="Narghilea 4Stars 410 AMY Deluxe">Narghilea 4Stars 410 AMY Deluxe</option>
<option value="Narghilea COCO BOSS- MINI TOWER 360°">Narghilea COCO BOSS- MINI TOWER 360°</option>
<option value="Narghilea Coco Boss Smoke Ladys">Narghilea Coco Boss Smoke Ladys</option>
<option value="Narghilea ALU SIERRA S AMY Deluxe">Narghilea ALU SIERRA S AMY Deluxe</option>
<option value="Narghilea AMIRS KARAT X AMY Deluxe">Narghilea AMIRS KARAT X AMY Deluxe</option>
<option value="Narghilea STARBUZZ CARBINE 2.0 AMY Deluxe">Narghilea STARBUZZ CARBINE 2.0 AMY Deluxe</option>
<option value="Narghilea FOGGY AMY Deluxe">Narghilea FOGGY AMY Deluxe</option>
</select>
<br><br>
<div class="image">
<img src="../imagini/addbutton.png" alt="add button" style="width:3%" align="left" onclick="SetProduct()">
<br><br>
<label for="mesajId"><br></label>
<textarea type="text" id="mesajId" name="mesaj" minlength="1" style="width: 380px; height: 96px;">
</textarea>
</fieldset>
<br><br>
<input type="button" value="Trimite comanda" onclick="if (checkform()) this.form.submit();">
<input type="reset" name="resetBtn" value="Reseteaza formularul"/>
    </form>
	<br>
  </body>
</html>