<html>
  <head>
    <title>ParerileClientilor</title>
		 <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #B0C4DE;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
}
label {
    display: inline-block;
    margin-right: 50px;
}
form{
  font-size: 17px;
}
table, th, td {
  border: none;
}

fieldset {
  background: url('../../imagini/stars.png');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}

.styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    width: 100%;
}
.styled-table thead tr{
    border: 1px solid black;
    border-radius: 10px;
    color: black;
    text-align: left;
}
.styled-table th,
.styled-table td {
    padding: 6px 30px;
}
</style>	
<script type="text/javascript">
       function checkform()
            {
                if (verificaNume() && verificaPrenume() && verificaMesaj()
                )
                return true;
            }
            
        function verificaNume()
       {
        var stringNume = document.getElementById("numeId").value;
        var alfabet = "^[a-zA-Z]+$";
        var numecorect = true;
        if (stringNume.match(alfabet))
        {
            document.getElementById("numeId").style.background = "white";
            return true;
        }
        else
        {
            document.getElementById("numeId").style.background = "red";            
            numecorect = false;
        }
        if (!numecorect)
        {
          alert("Numele introdus este incorect!"); 
          return false;                       
        }
       }

       function verificaPrenume()
       {
        var stringNume = document.getElementById("prenumeId").value;
        var alfabet = "^[a-zA-Z]+$";
        var prenumecorect = true;
        if (stringNume.match(alfabet))
        {
            document.getElementById("prenumeId").style.background = "white";
            document.getElementById("prenumeId").innerHTML = "";
            return true;
        }
        else
        {
            document.getElementById("prenumeId").style.background = "red";            
            prenumecorect = false;
        }
        if (!prenumecorect)
        {
          alert("Prenumele introdus este incorect!"); 
          return false;                       
        }
       }

    function verificaMesaj() {
    var Recenzie = document.getElementById("mesajId").value;
    if (Recenzie=="")
        {alert("Va rugam completati campul recenzie!");
        document.getElementById("mesajId").style.background = "red";
        return false;
        } else {
        document.getElementById("mesajId").style.background = "green";
            return true;
        }
    }
  </script>
  </head>   
  <body>
     <div class="topnav">
     <a href="../../../index.php">Pagina Principala</a>
     <a href="../../../pagina1.php">Despre noi</a>
     <a href="../../pagina2.php">Produsele noastre</a>
     <a href="../pagina3.php">Plaseaza comanda</a>
     <a class="active" href="pagina4.php">Parerile Clientilor</a>
    </div>
	<br>
  <form method="post" action= "insert_recenzii.php">
    <br><br>
    <fieldset>
      <legend><strong>Adauga o recenzie:</strong></legend>
     <label for="numeId">Introduceti numele:
        <input type="text" name="nume" id="numeId"/></label>
     <br><br>
     <label for="prenumeId">Introduceti prenumele:
     <input type="text" name="prenume" id="prenumeId"/></label>
     <br><br>
     <label for="mesajId">Va rugam introduceti recenzia d-voastra:<br></label>
      <textarea id="mesajId" name="mesaj" minlength="1" style="width: 325px; height: 96px;"></textarea>
    </fieldset>
      <br><br>
      <input type="button" value="Trimite recenzia" onclick="if (checkform()) this.form.submit();">
      <input type="reset" name="resetBtn" value="Reseteaza formularul"/>
    </form>
    <br><br><br>
<fieldset>
  <legend><strong>Recenziile clientilor:</strong><br></legend>
<table class="styled-table" align="right">
    <thead>
    <tr>
      <td><b>Nume</b></td>
      <td><b>Prenume</b></td>
      <td><b>Recenzie</b></td>
    </tr>
  </thead>
</fieldset>
<?php include "../connect_database.php" ?>
    <?php 
    $sql = "SELECT * FROM `recenzii`ORDER BY id DESC";
    $result = $conn->query($sql);
      if ($result->num_rows > 0)
      {
        while ($row = $result->fetch_assoc()) 
        {
        echo "<tr><td>" .$row["Nume"]. "</td><td>". $row["Prenume"] ."</td><td>" . $row["Recenzie"]. "</td></tr>";
        }
      }
      else
      {
        echo "Nu sunt rezultate!";
      }

    $conn->close();
    ?>

</div>
  </body>
</html>