<html>
    <head>
    <title>Recenzii</title>
    <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background: url('../../imagini/ThankYou1.png');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
    </head>
    <body>
<div class="topnav">
     <a href="../../../index.php">Pagina Principala</a>
     <a href="../../../pagina1.php">Despre noi</a>
     <a href="../../pagina2.php">Produsele noastre</a>
     <a href="../pagina3.php">Plaseaza comanda</a>
     <a class="active" href="pagina4.php">Parerile Clientilor</a>
    </div>
        <br><br>
			<strong>Se salveaza recenzia!</strong>
      <br><br>
			<?php 
			include '../connect_database.php';
			  echo "Salutare ... recenzia pe care dorim sa o salvam este: <br><br><br>Nume: ".$_POST['nume']."<br>Prenume:".$_POST['prenume']."<br>Recenzie:".$_POST['mesaj'];
            $sql = "INSERT INTO recenzii (Nume, Prenume, Recenzie) VALUES ('".$_POST["nume"]."','".$_POST["prenume"]."','".$_POST["mesaj"]."')";
			if ($conn->query($sql) === TRUE) {
				echo "<br><br>New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
			?>
        <br>
        </div>
    </body>
</html>